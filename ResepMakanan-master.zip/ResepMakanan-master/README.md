# ResepMakanan
Aplikasi Resep Makanan - Android Studio

# Tutorial Build with Android Studio
https://youtu.be/PX15pj-aHPU

# Tutorial Build with Step by Step
https://rivaldi48.blogspot.com/2020/06/Tutorial-Membuat-Aplikasi-Resep-Makanan-dengan-Android-Studio.html
