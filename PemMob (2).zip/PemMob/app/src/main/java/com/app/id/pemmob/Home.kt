package com.app.id.pemmob

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import com.app.id.pemmob.model.holdData
import kotlinx.android.synthetic.main.activity_home.*

class Home : AppCompatActivity() {

    lateinit var data: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        isiData()

//        tvNIM_home.setText(holdData.bio[0])
//        tvNama_home.setText(holdData.bio[1])

    }

    fun isiData(){
        data = ArrayList()

        for(i in 0 until 10){
            data.add("Data ke " + i)
        }

//        for(biodata in holdData.bio){
//            data.add(biodata)
//        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, data)
        lvData.adapter = adapter
    }
}