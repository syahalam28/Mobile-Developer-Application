package com.app.id.pemmob.model

object holdData {
    var bio = ArrayList<String>()
    var nama: String = ""

    fun setBio(bio: ArrayList<String>): ArrayList<String>{
        this.bio = bio
        return bio
    }

    fun setNama(nama: String): String{
        this.nama = nama
        return nama
    }

}