package com.app.id.pemmob.model

class biodata {
    var nim: String = ""
    var nama: String = ""
    var username: String = ""
    var password: String = ""

    constructor(nim: String, nama: String, username: String, password: String) {
        this.nim = nim
        this.nama = nama
        this.username = username
        this.password = password
    }

    constructor(username: String, password: String) {
        this.username = username
        this.password = password
    }


}