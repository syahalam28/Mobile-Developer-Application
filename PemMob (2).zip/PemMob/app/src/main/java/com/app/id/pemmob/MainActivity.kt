package com.app.id.pemmob

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.app.id.pemmob.model.holdData
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_register.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvRegister.setOnClickListener {
            startActivity(Intent(this@MainActivity, Register::class.java))
        }

        btnSubmit.setOnClickListener {
            if(holdData.bio.size != 0){
                if(getUsername() == holdData.bio[2] && getPasswrod() == holdData.bio[3]){
                    startActivity(Intent(this@MainActivity, Home::class.java))
                }else{
                    Toast.makeText(this@MainActivity, "Username atau Password Salah!", Toast.LENGTH_SHORT).show()
                }
            }else{
                Toast.makeText(this@MainActivity, "Anda belum mendaftar!", Toast.LENGTH_SHORT).show()
            }

        }
    }

    fun getUsername(): String{
        return txtUsername.text.toString()
    }

    fun getPasswrod(): String{
        return txtPassword.text.toString()
    }
}