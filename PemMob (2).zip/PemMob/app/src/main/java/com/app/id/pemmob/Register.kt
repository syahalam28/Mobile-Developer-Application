package com.app.id.pemmob

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.app.id.pemmob.model.*
import kotlinx.android.synthetic.main.activity_register.*

class Register : AppCompatActivity() {

    var tempBio = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        btnRegister.setOnClickListener {
            storeData()
        }

    }

    fun storeData(){
        holdData.bio.clear()

        tempBio.add(getNim())
        tempBio.add(getNama())
        tempBio.add(getUsername())
        tempBio.add(getPasswrod())

        holdData.setBio(tempBio)
        Toast.makeText(this@Register, "Sukses Register!", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this@Register, MainActivity::class.java))
    }

    fun getNama(): String{
        return txtNama.text.toString()
    }

    fun getNim(): String{
        return txtNim.text.toString()
    }

    fun getUsername(): String{
        return txtUsername_register.text.toString()
    }

    fun getPasswrod(): String{
        return txtPassword_register.text.toString()
    }

}