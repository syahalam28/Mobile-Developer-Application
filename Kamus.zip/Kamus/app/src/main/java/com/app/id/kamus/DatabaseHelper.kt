package com.app.id.jadwal.dbHelper

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.app.id.kamus.kelas
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.ArrayList

class DatabaseHelper(private val context: Context) {

    private var db: SQLiteDatabase? = null
    var listData = ArrayList<kelas>()

    companion object {

        private val DB_NAME = "kamus.db"
    }

    fun openDatabase(): SQLiteDatabase {
        val dbFile = context.getDatabasePath(DB_NAME)


        if (!dbFile.exists()) {
            try {
                val checkDB = context.openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null)

                checkDB?.close()
                copyDatabase(dbFile)
            } catch (e: IOException) {
                throw RuntimeException("Error creating source database", e)
            }

        }
        return SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READWRITE)
    }

    @SuppressLint("WrongConstant")
    private fun copyDatabase(dbFile: File) {
        val `is` = context.assets.open(DB_NAME)
        val os = FileOutputStream(dbFile)

        val buffer = ByteArray(1024)
        while (`is`.read(buffer) > 0) {
            os.write(buffer)
            Log.d("#DB", "writing>>")
        }

        os.flush()
        os.close()
        `is`.close()
        Log.d("#DB", "completed..")
    }

    fun queryAll(): Cursor {

        val db = openDatabase()

        return db.rawQuery("select * from data",null)
    }

//
    fun Cari(cari: String): Cursor {

        val db = openDatabase()
        return db.rawQuery("select * from data where inggris LIKE '%$cari%' ",null)
    }
//
//    fun getFromDay(hari: String): makul {
//        var listTanbungan = ArrayList<makul>()
//        val db = openDatabase()
//        val selectQuery = "select j.id_jadwal, h.nama_hari, j.nama_jadwal, j.jam, j.ruangan from hari h join jadwal j on h.id_hari=j.id_hari where h.nama_hari = '$hari' "
//        val cursor = db.rawQuery(selectQuery, null)
//        val n = makul(hari)
//
//        if (cursor.moveToFirst()) {
//            do {
//                n.ID_Jadwal = cursor.getInt(cursor.getColumnIndex("id_jadwal"))
//                n.nama_hari = cursor.getString(cursor.getColumnIndex("nama_hari"))
//                n.nama_jadwal = cursor.getString(cursor.getColumnIndex("nama_jadwal"))
//                n.jam = cursor.getString(cursor.getColumnIndex("jam"))
//                n.ruang = cursor.getString(cursor.getColumnIndex("ruangan"))
//                listTanbungan.add(n)
//            } while (cursor.moveToNext())
//        }
//
//        return n
//    }

    fun insertData(`in`: kelas) {
        val db = openDatabase()
        val values = ContentValues()
        values.put("inggris", `in`.inggris)
        values.put("indonesia", `in`.indonesia)
        db.insert("data", null, values)
    }

//    fun queryCek(): Cursor {
//
//        val db = openDatabase()
//        return return db!!.rawQuery("Select sum(jumlah_pinjam) as jumlah from peminjaman", null)
//
//    }

    fun updateData(`in`: kelas) {
        val db = openDatabase()
        val values = ContentValues()
        values.put("inggris", `in`.inggris)
        values.put("indonesia", `in`.indonesia)

        db.update("data", values, "id_data" + " = ? ",
            arrayOf<String>((`in`.id_data.toString()))
        )
    }


}


