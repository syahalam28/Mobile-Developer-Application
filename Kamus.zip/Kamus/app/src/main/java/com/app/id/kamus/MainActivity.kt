package com.app.id.kamus

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.app.id.jadwal.dbHelper.DatabaseHelper
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var listData = ArrayList<kelas>()
    lateinit var txtInggris : EditText
    lateinit var txtindonesia: EditText
    lateinit var imgEdit: ImageView

    var id_data: String = ""
    var inggris: String = ""
    var indonesia: String = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = DatabaseHelper(this)
        db.openDatabase()

        loadQueryAll()

        fab.setOnClickListener {
            addData()
        }

        lvShowdata.setOnLongClickListener(object: View.OnLongClickListener {
            override fun onLongClick(v: View?): Boolean {
                val builder = AlertDialog.Builder(this@MainActivity)
                val inflater = this@MainActivity.layoutInflater
                val view = inflater.inflate(R.layout.add, null)

                val txtInggris = view.findViewById<EditText>(R.id.txtInggris)
                val txtIndonesia = view.findViewById<EditText>(R.id.txtIndonesia)
                val id : TextView = view.findViewById<TextView>(R.id.tvGetid)

                builder.setPositiveButton("Ubah") { dialog, which ->
                    Log.e("ID", id.text.toString())
                }


                builder.setView(view)
                val al = builder.create()
                al.show()
                return true
            }
        })

        lvShowdata.setOnItemClickListener { parent, view, position, id ->
            imgEdit = view.findViewById<ImageView>(R.id.imgEdit)
            inggris = view.findViewById<TextView>(R.id.tvInggris).text.toString()
            indonesia = view.findViewById<TextView>(R.id.tvIndonesia).text.toString()
            id_data = view.findViewById<TextView>(R.id.tvId).text.toString()

            imgEdit.setOnClickListener {
                editData()
            }
        }

        txtCari.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                loadCari(s.toString())
            }
        })

    }

    fun loadQueryAll() {
        val adb = DatabaseHelper(this)
        val cursor = adb.queryAll()

        listData.clear()
        if (cursor.moveToFirst()) {

            do {
                val id = cursor.getInt(cursor.getColumnIndex("id_data"))
                val inggris = cursor.getString(cursor.getColumnIndex("inggris"))
                val indonesia = cursor.getString(cursor.getColumnIndex("indonesia"))

                listData.add(kelas(id, inggris, indonesia))

            } while (cursor.moveToNext())
        }

        var adp = adater(this, listData)
        lvShowdata.adapter = adp
    }

    fun addData(){
        val builder = AlertDialog.Builder(this@MainActivity)
        val inflater = this@MainActivity.layoutInflater
        val view = inflater.inflate(R.layout.add, null)

        txtInggris = view.findViewById<EditText>(R.id.txtInggris)
        txtindonesia = view.findViewById<EditText>(R.id.txtIndonesia)

        builder.setPositiveButton("Tambah"){dialog, which ->
            val adb = DatabaseHelper(this)
            adb.insertData(kelas(txtInggris.text.toString(), txtindonesia.text.toString()))
            loadQueryAll()
        }

        builder.setView(view)
        val al = builder.create()
        al.show()
    }

    fun editData(){
        val builder = AlertDialog.Builder(this@MainActivity)
        val inflater = this@MainActivity.layoutInflater
        val view = inflater.inflate(R.layout.add, null)

        val txtInggrisEdit = view.findViewById<EditText>(R.id.txtInggris)
        val txtIndonesiaEdit = view.findViewById<EditText>(R.id.txtIndonesia)
        val id = view.findViewById<TextView>(R.id.tvGetid)
        val title = view.findViewById<TextView>(R.id.tvAdd)

        title.setText("Ubah data")
        txtInggrisEdit.setText(inggris)
        txtIndonesiaEdit.setText(indonesia)
        id.setText(id_data)

        builder.setPositiveButton("Ubah"){dialog, which ->
            val adb = DatabaseHelper(this)
            adb.updateData(kelas(txtInggrisEdit.text.toString(), txtIndonesiaEdit.text.toString(), id.text.toString().toInt()))
            loadQueryAll()
        }

        builder.setView(view)
        val al = builder.create()
        al.show()
    }

    fun loadCari(data : String){
        val adb = DatabaseHelper(this)
        val cursor = adb.Cari(data)

        listData.clear()
        if (cursor.moveToFirst()) {

            do {
                val id = cursor.getInt(cursor.getColumnIndex("id_data"))
                val inggris = cursor.getString(cursor.getColumnIndex("inggris"))
                val indonesia = cursor.getString(cursor.getColumnIndex("indonesia"))

                listData.add(kelas(id, inggris, indonesia))

            } while (cursor.moveToNext())
        }

        var adp = adater(this, listData)
        lvShowdata.adapter = adp
    }

}