package com.app.id.kamus

class kelas {
    var id_data: Int = 0
    var inggris: String = ""
    var indonesia: String = ""

    constructor()

    constructor(id_data: Int){
        this.id_data = id_data
    }

    constructor(inggris: String, indonesia: String){
        this.inggris = inggris
        this.indonesia = indonesia
    }

    constructor(id_data: Int, inggris: String, indonesia: String) {
        this.id_data = id_data
        this.inggris = inggris
        this.indonesia = indonesia
    }

    constructor(inggris: String, indonesia: String, id_data: Int) {
        this.id_data = id_data
        this.inggris = inggris
        this.indonesia = indonesia
    }


}